@extends('admin.layout.default')
@section('css')

@endsection

@section('jsPostApp')
@endsection

@section('content')
<div class="main-container">

</div>
@endsection
