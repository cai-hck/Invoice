<!doctype html>
<html dir="rtl" lang="ar">
<head>
<meta charset="utf-8">
<title>Forgot Password</title>

</head>

<body>
  	<a href="{{url('http://localhost:8000/resetpassword/'. $user->api_token)}}">لإعادة ضبط كلمة المرور ، يرجى الضغط على الرابط التالي</a>
</body>
</html>
