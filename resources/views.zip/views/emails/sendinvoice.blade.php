<!doctype html>
<html dir="rtl" lang="ar">
<head>
<meta charset="utf-8">
<title>{{$companyname}}-{{$id}}</title>

</head>

<body>
    <a href="{{asset('upload/pdf/'.$name)}}" download id="downloadpdf">فاتورة مبيعات {{$companyname}}</a>
</body>
</html>
